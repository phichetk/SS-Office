<?
include 'allconfig.conf';
// Start mysql link
$link = mysql_connect($hostname, $username, $password);
if (!$link) {
   die('Could not connect: ' . mysql_error());
}
// End mysql Link

mysql_select_db($dbname);

?>
