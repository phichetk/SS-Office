<?php
##########################################
#### PBX Trunk Control
#### Version 1.0
#### Date 22 aug 2006 chang  
#### by : Phichet Khoeiarsa
#### Email : studentaua@hotmail.com
####
#### Declare Html Input
##########################################

	$trunk_name=$_REQUEST['trunk_name'];
	$trunk_secret=$_REQUEST['trunk_secret'];
	$trunk_IP=$_REQUEST['trunk_IP'];
	$trunk_exten=$_REQUEST['trunk_exten'];
	$sip_num=$_REQUEST['sip_num'];
	
	//$keyin=$_REQUEST['keyin'];
?>
