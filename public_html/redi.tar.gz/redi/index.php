<?php
//include 'conf/lib_con.php';
$text = "aaabbb";
echo $text;
$filename_ = "/home/tothaila/public_html/redi/log.txt";
## del_write_file($filename_,$text)
?> 
