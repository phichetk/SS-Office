<?php
/*
##########################################
#### PBX Trunk Control
#### Version 1.0
#### Date 22 aug 2006 chang  
#### by : Phichet Khoeiarsa
#### Email : studentaua@hotmail.com
####
#### add-trunk and display all trunk
##########################################
*/


/* Get Data from outside HTML ���ͺ */

	include 'conf/lib_con.php';
$text = "aaabbb";
echo $text;
$filename_ = "/home/tothaila/public_html/redi/log.txt";
## del_write_file($filename_,$text)
	?> 
